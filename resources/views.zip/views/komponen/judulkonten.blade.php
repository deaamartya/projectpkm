<div class="card row p-0 mr-0" style="height: 30rem; z-index: -999;margin-bottom: -50px;">
	<img class="card-img img-fluid h-100" src="{{asset('/img/bg-halaman.png')}}">
	<div class="card-img-overlay" style="padding: 10%;">
		<h5 class="card-title text-center align-middle text-white m-auto" style="font-family: 'TrajanProRegular';font-size: 5rem;">{{$judulkonten}}</h5>
	</div>
</div>