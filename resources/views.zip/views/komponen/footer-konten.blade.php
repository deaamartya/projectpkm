<footer>
	<div class="row m-0 p-2" style="background-color: #ffb72b;">
		<div class="container">
            <a class="m-1" style="display: inline-block;" title="Facebook" target="_blank" href="https://www.facebook.com/universitasairlangga">
		        <img alt="Facebook" class="ua-ms" src="http://unair.ac.id/uploads/module/social-media/5d71048979050a63ed58ad0f0b07efd8.png" width="20">
		    </a>
		    <a class="m-1" style="display: inline-block;" title="Instagram" target="_blank" href="https://www.instagram.com/univ_airlangga/">
		        <img alt="Instagram" class="ua-ms" src="http://unair.ac.id/uploads/module/social-media/d10218fedd3c2da5a83ffa23022f38b2.png" width="20">
		    </a>
		    <a class="m-1" style="display: inline-block;" title="Twitter" target="_blank" href="https://twitter.com/Unair_Official">
		        <img alt="Twitter" class="ua-ms" src="http://unair.ac.id/uploads/module/social-media/b513b6870124b9ed4f8ebb2b5c050889.png" width="20">
		    </a>
		    <a class="m-1" style="display: inline-block;" title="Youtube" target="_blank" href="https://www.youtube.com/channel/UCUYwloXmWyNZplsqg4MVERw">
		        <img alt="Youtube" class="ua-ms" src="http://unair.ac.id/uploads/module/social-media/919ad973cea8ff1fe39798644543cd58.png" width="20">
		    </a>
		    <a class="m-1" style="display: inline-block;" title="Radio" target="_blank" href="http://radiounair.com">
		        <img alt="Radio" class="ua-ms" src="http://unair.ac.id/uploads/module/social-media/d398fa3e66299149c543df83fab79b33.png" width="20">
		    </a>
        </div>
	</div>
	<div class="row m-0" style="background-color: #3c3c3c;">
		<div class="col-xl-8 py-4 px-4 textinfo text-white">
			Copyright 2020. Universitas Airlangga. All Rights Reserved.
		</div>
		<div class="col-xl-4 py-4 px-4 align-middle">
			<span class="text-white align-middle textinfo"><b>UNAIR Information and Public Relations Center</b><br>
			<br>Management Office, 2nd Floor Amerta-2
			<br>Kampus C Mulyorejo, Surabaya
			<br>Phone (+62 31)  5914042, 5914043,5915551 ext. 102 Fax (+62 31) 5915551
			<br>Email : adm@pih.unair.ac.id</span>
		</div>
	</div>
</footer>